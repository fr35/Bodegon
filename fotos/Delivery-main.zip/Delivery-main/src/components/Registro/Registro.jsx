export default function Registro() {
    return (
        <form className="d-inline p-2">
            <button className="btn btn-outline-light" type="submit">
                Iniciar Sesión
            </button>
        </form>
    )
}