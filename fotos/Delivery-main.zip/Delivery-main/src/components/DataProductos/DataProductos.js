const Hamburguesa = () => {
    [
        {
            "id": 1,
            "nombre": "Martynne Toombes",
            "price": 916,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 9
        }, 
        {
            "id": 2,
            "nombre": "Terrel Rizzello",
            "price": 1083,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 2
        }, 
        {
            "id": 3,
            "nombre": "Inesita Lemmertz",
            "price": 1316,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 15
        }, 
        {
            "id": 4,
            "nombre": "Wallie Macauley",
            "price": 1494,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 4
        }, 
        {
            "id": 5,
            "nombre": "Jamison Saleway",
            "price": 1320,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 12
        }, 
        {
            "id": 6,
            "nombre": "Iolanthe Marsters",
            "price": 923,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 8
        }, 
        {
            "id": 7,
            "nombre": "Aguste Cossans",
            "price": 824,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 13
        }, 
        {
            "id": 8,
            "nombre": "Jonathan Pickthall",
            "price": 1254,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 2
        }, 
        {
            "id": 9,
            "nombre": "Iseabal Bellson",
            "price": 1348,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 5
        }, 
        {
            "id": 10,
            "nombre": "Jaquith McKinna",
            "price": 971,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 5
        }, 
        {
            "id": 11,
            "nombre": "Jessalyn Berkley",
            "price": 1587,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 8
        }, 
        {
            "id": 12,
            "nombre": "Barnaby Domsalla",
            "price": 1349,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 15
        }, 
        {
            "id": 13,
            "nombre": "Fidel Treacy",
            "price": 1997,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 10
        }, 
        {
            "id": 14,
            "nombre": "Shurlock Ollerhead",
            "price": 958,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 7
        }, 
        {
            "id": 15,
            "nombre": "Bale Storrock",
            "price": 1408,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 5
        }, 
        {
            "id": 16,
            "nombre": "Imojean Burles",
            "price": 1315,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 1
        }, 
        {
            "id": 17,
            "nombre": "Noble Bynold",
            "price": 1071,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 8
        }, 
        {
            "id": 18,
            "nombre": "Lora McKennan",
            "price": 1026,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 5
        }, 
        {
            "id": 19,
            "nombre": "Peterus Handes",
            "price": 1660,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 13
        }, 
        {
            "id": 20,
            "nombre": "Avrit Broke",
            "price": 1244,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 14
        }, 
        {
            "id": 21,
            "nombre": "Stanfield Urling",
            "price": 868,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 11
        }, 
        {
            "id": 22,
            "nombre": "Carlotta Dechelette",
            "price": 1955,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 3
        }, 
        {
            "id": 23,
            "nombre": "Ilise Harbage",
            "price": 1702,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 3
        }, 
        {
            "id": 24,
            "nombre": "Lexy Sansbury",
            "price": 1458,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 15
        }, 
        {
            "id": 25,
            "nombre": "Deeanne Doll",
            "price": 1832,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 7
        }, 
        {
            "id": 26,
            "nombre": "Ameline Juares",
            "price": 1668,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 8
        }, 
        {
            "id": 27,
            "nombre": "Lindy Huskisson",
            "price": 1119,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 1
        }, 
        {
            "id": 28,
            "nombre": "Tanya Tarborn",
            "price": 996,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 12
        }, 
        {
            "id": 29,
            "nombre": "Harriette Madelin",
            "price": 1532,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 13
        }, 
        {
            "id": 30,
            "nombre": "Gearard Garken",
            "price": 818,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 4
        }
    ]
}

const Pizzas = () => {
    [
        {
            "id": 1,
            "nombre": "Karena Arnson",
            "price": 1733,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 15
        }, 
        {
            "id": 2,
            "nombre": "Nataline Warrior",
            "price": 846,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 12
        }, 
        {
            "id": 3,
            "nombre": "Pauli Shipton",
            "price": 1851,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 1
        }, 
        {
            "id": 4,
            "nombre": "Sergio Roderham",
            "price": 1800,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 15
        }, 
        {
            "id": 5,
            "nombre": "Augie Klimkov",
            "price": 1688,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 14
        }, 
        {
            "id": 6,
            "nombre": "Binnie Heaselgrave",
            "price": 1682,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 4
        }, 
        {
            "id": 7,
            "nombre": "Chrystal Flynn",
            "price": 1542,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 4
        }, 
        {
            "id": 8,
            "nombre": "Thea Van Arsdall",
            "price": 988,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 5
        }, 
        {
            "id": 9,
            "nombre": "Alexandra Doonican",
            "price": 1922,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 15
        }, 
        {
            "id": 10,
            "nombre": "Domenico Happer",
            "price": 1994,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 9
        }, 
        {
            "id": 11,
            "nombre": "Desdemona Wiles",
            "price": 1029,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 13
        }, 
        {
            "id": 12,
            "nombre": "Chloris Inker",
            "price": 1974,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 5
        }, 
        {
            "id": 13,
            "nombre": "Giavani Veck",
            "price": 1244,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 4
        }, 
        {
            "id": 14,
            "nombre": "Guthry Ciccotto",
            "price": 1719,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 12
        }, 
        {
            "id": 15,
            "nombre": "Mariam Oleszkiewicz",
            "price": 1842,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 14
        }, 
        {
            "id": 16,
            "nombre": "Jasmin Rupke",
            "price": 1082,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 14
        }, 
        {
            "id": 17,
            "nombre": "Roldan Dreye",
            "price": 1209,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 2
        }, 
        {
            "id": 18,
            "nombre": "Aidan Hiddersley",
            "price": 1372,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 1
        }, 
        {
            "id": 19,
            "nombre": "Luci Arrigo",
            "price": 1526,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 10
        }, 
        {
            "id": 20,
            "nombre": "Alina Farnall",
            "price": 1173,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 13
        }, 
        {
            "id": 21,
            "nombre": "Immanuel Joules",
            "price": 1219,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 5
        }, 
        {
            "id": 22,
            "nombre": "Hollie Tesimon",
            "price": 1815,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 6
        }, 
        {
            "id": 23,
            "nombre": "Faustine Riddock",
            "price": 1324,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 14
        }, 
        {
            "id": 24,
            "nombre": "Tedda Champneys",
            "price": 1481,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 11
        }, 
        {
            "id": 25,
            "nombre": "Wilmette McGrale",
            "price": 1956,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 11
        }, 
        {
            "id": 26,
            "nombre": "Nettle Vallerine",
            "price": 1688,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 4
        }, 
        {
            "id": 27,
            "nombre": "Derk Dixey",
            "price": 1136,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 8
        }, 
        {
            "id": 28,
            "nombre": "Drucill Thying",
            "price": 1209,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 9
        }, 
        {
            "id": 29,
            "nombre": "Sherwood Oxbie",
            "price": 1341,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 9
        }, 
        {
            "id": 30,
            "nombre": "Demetrius Gaylord",
            "price": 1785,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 11
        }
    ]
}

const Milanesas = () => {
    [
        {
            "id": 1,
            "nombre": "Caspar Mourbey",
            "price": 1015,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 7
        }, 
        {
            "id": 2,
            "nombre": "Queenie Khadir",
            "price": 1557,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 8
        }, 
        {
            "id": 3,
            "nombre": "Yetta Chrystal",
            "price": 1208,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 7
        }, 
        {
            "id": 4,
            "nombre": "Merry Davio",
            "price": 1935,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 1
        }, 
        {
            "id": 5,
            "nombre": "Drucie Vella",
            "price": 991,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 13
        }, 
        {
            "id": 6,
            "nombre": "Katleen Allnutt",
            "price": 991,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 2
        }, 
        {
            "id": 7,
            "nombre": "Padraig Bonsale",
            "price": 1420,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 13
        }, 
        {
            "id": 8,
            "nombre": "Shelby Matashkin",
            "price": 1803,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 7
        }, 
        {
            "id": 9,
            "nombre": "Garrick Wykey",
            "price": 870,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 7
        }, 
        {
            "id": 10,
            "nombre": "Amelia Sowle",
            "price": 1406,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 15
        }, 
        {
            "id": 11,
            "nombre": "Basilio Paule",
            "price": 1644,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 4
        }, 
        {
            "id": 12,
            "nombre": "Kip Vallery",
            "price": 1121,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 11
        }, 
        {
            "id": 13,
            "nombre": "Emlynne Chillcot",
            "price": 1707,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 4
        }, 
        {
            "id": 14,
            "nombre": "Clarie Wehden",
            "price": 1290,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 11
        }, 
        {
            "id": 15,
            "nombre": "Lottie Sancraft",
            "price": 1822,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 15
        }, 
        {
            "id": 16,
            "nombre": "Cal MacCaughen",
            "price": 1545,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 15
        }, 
        {
            "id": 17,
            "nombre": "Trudey Templar",
            "price": 1355,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 10
        }, 
        {
            "id": 18,
            "nombre": "Cassandre Puttan",
            "price": 819,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 3
        }, 
        {
            "id": 19,
            "nombre": "Evangeline Cadwaladr",
            "price": 1848,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 10
        }, 
        {
            "id": 20,
            "nombre": "Calley McGinney",
            "price": 987,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 3
        }
    ]
}

const Helados = () => {
    [
        {
            "id": 1,
            "nombre": "Barde Videan",
            "price": 1272,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 6
        }, 
        {
            "id": 2,
            "nombre": "Marlowe Beever",
            "price": 1817,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 11
        }, 
        {
            "id": 3,
            "nombre": "Donetta Pidgeley",
            "price": 987,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 9
        }, 
        {
            "id": 4,
            "nombre": "Barbabra Boydell",
            "price": 1934,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 3
        }, 
        {
            "id": 5,
            "nombre": "Law Gibbett",
            "price": 1203,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 15
        }, 
        {
            "id": 6,
            "nombre": "Wenonah Reeveley",
            "price": 1719,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 7
        }, 
        {
            "id": 7,
            "nombre": "Minda Van der Spohr",
            "price": 1961,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 1
        }, 
        {
            "id": 8,
            "nombre": "Annabel Spawton",
            "price": 1202,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 1
        }, 
        {
            "id": 9,
            "nombre": "Efren Cabrera",
            "price": 1327,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 2
        }, 
        {
            "id": 10,
            "nombre": "Felicdad Knight",
            "price": 1929,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 10
        }, 
        {
            "id": 11,
            "nombre": "Hayward Longson",
            "price": 1369,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 13
        }, 
        {
            "id": 12,
            "nombre": "Alisa Newland",
            "price": 1868,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 11
        }, 
        {
            "id": 13,
            "nombre": "Damian Iles",
            "price": 1934,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 14
        }, 
        {
            "id": 14,
            "nombre": "Joeann Verrill",
            "price": 987,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 10
        }, 
        {
            "id": 15,
            "nombre": "Ewen Sewter",
            "price": 1955,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 8
        }, 
        {
            "id": 16,
            "nombre": "Gradey Norrie",
            "price": 971,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 10
        }, 
        {
            "id": 17,
            "nombre": "Yance Kyston",
            "price": 1108,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 2
        }, 
        {
            "id": 18,
            "nombre": "Binnie Negro",
            "price": 944,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 13
        }, 
        {
            "id": 19,
            "nombre": "Evaleen Traynor",
            "price": 1144,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 3
        }, 
        {
            "id": 20,
            "nombre": "Junina Banghe",
            "price": 1167,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 1
        }
    ]
}

const Pastas = () => {
    [
        {
            "id": 1,
            "nombre": "Mannie Reveley",
            "price": 1008,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 11
        }, 
        {
            "id": 2,
            "nombre": "Rodolph Measor",
            "price": 1528,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 1
        }, 
        {
            "id": 3,
            "nombre": "Meriel Blasgen",
            "price": 1177,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 2
        }, 
        {
            "id": 4,
            "nombre": "Candide Mival",
            "price": 1616,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 10
        }, 
        {
            "id": 5,
            "nombre": "Gradey Patifield",
            "price": 1202,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 13
        }, 
        {
            "id": 6,
            "nombre": "Henka Gaenor",
            "price": 1168,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 9
        }, 
        {
            "id": 7,
            "nombre": "Lorrayne Kilban",
            "price": 1106,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 8
        }, 
        {
            "id": 8,
            "nombre": "Onfroi Calrow",
            "price": 1318,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 13
        }, 
        {
            "id": 9,
            "nombre": "Sindee Chislett",
            "price": 1023,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 12
        }, 
        {
            "id": 10,
            "nombre": "Tiphani Larrie",
            "price": 1060,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 10
        }
    ]
}

const Postres = () => {
    [
        {
            "id": 1,
            "nombre": "Janaye Lambal",
            "price": 1575,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 2
        }, 
        {
            "id": 2,
            "nombre": "Dniren Boyde",
            "price": 1876,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 10
        }, 
        {
            "id": 3,
            "nombre": "Adams Goodier",
            "price": 870,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 11
        }, 
        {
            "id": 4,
            "nombre": "Darcee Oldacres",
            "price": 1444,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 7
        }, 
        {
            "id": 5,
            "nombre": "Floria Monnery",
            "price": 964,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 7
        }, 
        {
            "id": 6,
            "nombre": "Cassius Duggon",
            "price": 1605,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 12
        }, 
        {
            "id": 7,
            "nombre": "Abe Ruggieri",
            "price": 1675,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 5
        }
    ]
}

const Oferta = () => {
    [
        {
            "id": 1,
            "nombre": "Alexis Augustine",
            "price": 1864,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 6,
            "descuento": 13
        }, 
        {
            "id": 2,
            "nombre": "Gael Romney",
            "price": 1469,
            "img": "http://dummyimage.com/200x200.png/5fa2dd/ffffff",
            "stock": 6,
            "descuento": 18
        }, 
        {
            "id": 3,
            "nombre": "Agnese Halwill",
            "price": 1067,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 14,
            "descuento": 21
        }, 
        {
            "id": 4,
            "nombre": "Elana Eburne",
            "price": 1096,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 10,
            "descuento": 5
        }, 
        {
            "id": 5,
            "nombre": "Hetti Vail",
            "price": 1394,
            "img": "http://dummyimage.com/200x200.png/ff4444/ffffff",
            "stock": 5,
            "descuento": 18
        }, 
        {
            "id": 6,
            "nombre": "Junette Skyner",
            "price": 1463,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 15,
            "descuento": 10
        }, 
        {
            "id": 7,
            "nombre": "Kermit Coolahan",
            "price": 1759,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 12,
            "descuento": 10
        }, 
        {
            "id": 8,
            "nombre": "Clementius Bradnock",
            "price": 979,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 2,
            "descuento": 13
        }, 
        {
            "id": 9,
            "nombre": "Leonelle Terne",
            "price": 1368,
            "img": "http://dummyimage.com/200x200.png/dddddd/000000",
            "stock": 5,
            "descuento": 12
        }, 
        {
            "id": 10,
            "nombre": "Tedmund Kender",
            "price": 1050,
            "img": "http://dummyimage.com/200x200.png/cc0000/ffffff",
            "stock": 12,
            "descuento": 17
        }
    ]
}