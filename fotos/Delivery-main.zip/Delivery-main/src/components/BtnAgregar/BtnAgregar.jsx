export default function BtnAgregar({cantidad}) {
    return (
        <button className="btn btn-outline-dark" onClick={cantidad}>Agregar al Carrito</button>
    )
}